﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Inventory
{
    public class soldBooks : Books 
    {
        [Required]
        public short sold_copies
        {
            get;
            set;
        }
    }
}