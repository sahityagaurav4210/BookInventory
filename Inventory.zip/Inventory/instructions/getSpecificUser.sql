USE [Inventory]
GO

/****** Object:  StoredProcedure [dbo].[getSpecificUser]    Script Date: 7/14/2022 12:38:36 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Gaurav Sahitya
-- Create date: 13 July 2022
-- Description:	This stored procedure retrieves specific information about users.
-- =============================================

CREATE PROCEDURE [dbo].[getSpecificUser]

	-- Add the parameters for the stored procedure here
	@username varchar(50), @password varchar(50)

AS
BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT id,username,password,store_name FROM account WHERE username = @username AND password = HASHBYTES('SHA2_512',@password); 

END
GO

