USE [Inventory]
GO

/****** Object:  StoredProcedure [dbo].[alterTheExistingBook]    Script Date: 7/14/2022 12:37:52 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Gaurav Sahitya
-- Create date: 13 July 2022
-- Description:	This stored procedure alters the already present book records.
-- =============================================

CREATE PROCEDURE [dbo].[alterTheExistingBook] 
	-- Add the parameters for the stored procedure here
	@id int, @copies int

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	UPDATE books SET copies = @copies WHERE id = @id;

END
GO

