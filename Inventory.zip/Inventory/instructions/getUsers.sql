USE [Inventory]
GO

/****** Object:  StoredProcedure [dbo].[getUsers]    Script Date: 7/14/2022 12:38:45 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Gaurav Sahitya
-- Create date: 12 July 2022
-- Description:	This is a stored procedure which retrieves all data from the database table
-- =============================================
CREATE PROCEDURE [dbo].[getUsers]
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT * from [Inventory].[dbo].account;
END
GO

