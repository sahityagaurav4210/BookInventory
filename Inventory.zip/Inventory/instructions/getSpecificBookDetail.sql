USE [Inventory]
GO

/****** Object:  StoredProcedure [dbo].[getSpecificBookDetail]    Script Date: 7/14/2022 12:38:23 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Gaurav Sahitya
-- Create date: 13 July 2022
-- Description:	This stored procedure returns the specific id's specific bookDetail.
-- =============================================

CREATE PROCEDURE [dbo].[getSpecificBookDetail] 
	
	-- Add the parameters for the stored procedure here
	@id int

AS
BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT user_id,bookName,authorName,copies from books WHERE id = @id;

END
GO

