﻿1. Open the Inventory.sln file in Visual Studio 2015.

2. Open the Microsoft SQL Management Studio 2018 create the Inventory database in it.

3. After creating the database create 3 tables namely account,books,soldBooks. Queries for creating these tables are given in account.sql, books.sql, soldBooks.sql files which are present inside the instructions folder.

4. After creating the tables create 8 stored procedures namely addNewBook, addNewSoldBook, addNewUser, alterTheExistingBook, getAllPresentBooks, getSpecificBookDetail, getSpecificUser, getUsers. Queries for creating these stored procedures are given in addNewBook.sql, addNewSoldBook.sql, addNewUser.sql, alterTheExistingBook.sql, getAllPresentBooks.sql, getSpecificBookDetail.sql, getSpecificUser.sql and getUsers.sql files which are present inside the instructions folder.

5. Connect the created Inventory database with Visual Studio 2015 Inventory project from Server Explorer tab present in the left most area.

6. After connecting paste the connection string in connectionString variable of Repository.cs class.

7. Press F5 to run the project.

Note : VS 2015 and SSMS 2018 must be installed in the system.