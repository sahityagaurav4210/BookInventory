USE [Inventory]
GO

/****** Object:  StoredProcedure [dbo].[addNewUser]    Script Date: 7/14/2022 12:37:33 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Gaurav Sahitya
-- Create date: 12 July 2022
-- Description:	This stored procedure adds user's data
-- =============================================
CREATE PROCEDURE [dbo].[addNewUser]  
	-- Add the parameters for the stored procedure here
	@name varchar(50),@email varchar(50),@username varchar(50),@password varchar(50),@store_name varchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here

	INSERT INTO account (name,email,username,password,store_name) VALUES(@name,@email,@username,HASHBYTES('SHA2_512',@password),@store_name);
END
GO

