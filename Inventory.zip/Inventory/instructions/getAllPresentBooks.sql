USE [Inventory]
GO

/****** Object:  StoredProcedure [dbo].[getAllPresentBooks]    Script Date: 7/14/2022 12:38:07 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Gaurav Sahitya
-- Create date: 13 July 2022
-- Description:	This stored procedure retrieves all the books present in the books table.
-- =============================================

CREATE PROCEDURE [dbo].[getAllPresentBooks] 

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT * FROM books;

END
GO

