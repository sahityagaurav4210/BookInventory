USE [Inventory]
GO

/****** Object:  StoredProcedure [dbo].[addNewBook]    Script Date: 7/14/2022 12:36:38 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Gaurav Sahitya
-- Create date: 13 July 2022
-- Description:	This stored procedure is for adding new books into books table.
-- =============================================

CREATE PROCEDURE [dbo].[addNewBook] 
	
	-- Add the parameters for the stored procedure here
	@user_id int, @bookName varchar(50), @authorName varchar(50), @bookPrice money, @bookEdition varchar(50), @isbn varchar(50), @copies int

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	INSERT INTO books (user_id,bookName,authorName,bookPrice,bookEdition,isbn,copies) VALUES (@user_id,@bookName,@authorName,@bookPrice,@bookEdition,@isbn,@copies);	

END
GO

