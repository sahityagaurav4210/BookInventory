﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.ModelBinding;
using System.Text;

namespace Inventory
{
    public partial class Signin : System.Web.UI.Page
    {
        private Credentials cred = new Credentials();
        private Repository repository = new Repository();
        List<string> userDetails;

        protected void Page_Load(object sender, EventArgs e)
        {
            cnf_msg.InnerText = "";
        }

        protected void button1_Click(object sender, EventArgs e)
        {
            if(TryUpdateModel(cred, new FormValueProvider(ModelBindingExecutionContext)))
            {
                userDetails = repository.Retrieve(cred.username, cred.password);

                if(userDetails.Count > 1)
                {
                    Session.Add("username", cred.username);
                    Session.Add("sname", userDetails[1]);
                    Session.Add("id", userDetails[2]);

                    Response.Redirect("Admin.aspx");

                }
                else
                {
                    cnf_msg.InnerText = "";
                    cnf_msg.InnerText = "Invalid Credentials";
                    cnf_msg.Style.Add(HtmlTextWriterStyle.Color, "#EB1D36");
                }
            }
        }
    }
}