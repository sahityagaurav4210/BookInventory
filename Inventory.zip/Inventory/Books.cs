﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Inventory
{
    public class Books
    {

        internal short bookID
        {
            get;
            set;
        }

        [Required]
        protected internal string bookName
        {
            get;
            set;
        }

        [Required]
        protected internal string authorName
        {
            get;
            set;
        }

        [Required]
        protected internal int user_id
        {
            get;
            set;
        }

        [Required]
        internal decimal bookPrice
        {
            get;
            set;
        }

        [Required]
        internal string bookEdition
        {
            get;
            set;
        }

        [Required]
        internal string isbn
        {
            get;
            set;
        }

        [Required]
        internal short copies
        {
            get;
            set;
        }

    }
}