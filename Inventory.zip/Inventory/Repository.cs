﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace Inventory
{
    public class Repository
    {
        private string connectionString = "Data Source=DESKTOP-E7M9HV9;Initial Catalog=Inventory;Integrated Security=True";

        private SqlConnection sqlConnection;
        private SqlCommand sqlCommand;
        private SqlDataReader reader;

        public void Add(soldBooks book)
        {
            try
            {
                sqlConnection = new SqlConnection(connectionString);
                sqlConnection.Open();
                sqlCommand = new SqlCommand("EXEC addNewSoldBook @user_id='" + book.user_id + "',@bookName='" + book.bookName + "',@authorName='" + book.authorName + "',@sold_copies='" + book.sold_copies + "';", sqlConnection);
                sqlCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConnection.Close();
            }

        }


        public void Add(Books book)
        {

            try
            {
                sqlConnection = new SqlConnection(connectionString);
                sqlConnection.Open();
                sqlCommand = new SqlCommand("EXEC addNewBook @user_id='" + book.user_id + "',@bookName='" + book.bookName + "',@authorName='" + book.authorName + "',@bookPrice='" + book.bookPrice + "',@bookEdition='" + book.bookEdition + "',@isbn='" + book.isbn + "',@copies='" + book.copies + "';", sqlConnection);
                sqlCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConnection.Close();
            }

        }

        public void Add(Accounts acs)
        {

            try
            {
                sqlConnection = new SqlConnection(connectionString);
                sqlConnection.Open();
                sqlCommand = new SqlCommand("EXEC addNewUser @name='" + acs.Name + "',@email='" + acs.Email + "',@username='" + acs.Username + "',@password='" + acs.Password + "',@store_name='" + acs.Store_Name + "';", sqlConnection);
                sqlCommand.ExecuteNonQuery();
            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConnection.Close();
            }

        }

        public List<string> Retrieve(int id)
        {
            List<string> credentials = new List<string>();

            try
            {
                sqlConnection = new SqlConnection(connectionString);
                sqlConnection.Open();
                sqlCommand = new SqlCommand("EXEC getSpecificBookDetail @id='" + id + "';", sqlConnection);
                reader = sqlCommand.ExecuteReader();

                while (reader.Read())
                {
                    credentials.Add(reader["user_id"].ToString());
                    credentials.Add(reader["bookName"].ToString());
                    credentials.Add(reader["authorName"].ToString());
                    credentials.Add(reader["copies"].ToString());
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConnection.Close();
            }

            return credentials;
        }


        public List<Books> Retrieve()
        {
            List<Books> credentials = new List<Books>();

            try
            {
                sqlConnection = new SqlConnection(connectionString);
                sqlConnection.Open();
                sqlCommand = new SqlCommand("EXEC getAllPresentBooks;", sqlConnection);
                reader = sqlCommand.ExecuteReader();

                while (reader.Read())
                {
                    credentials.Add(new Books {
                        user_id = int.Parse(reader["user_id"].ToString()),
                        bookName = reader["bookName"].ToString(),
                        authorName = reader["authorName"].ToString(),
                        bookPrice = decimal.Parse(reader["bookPrice"].ToString()),
                        bookEdition = reader["bookEdition"].ToString(),
                        isbn = reader["isbn"].ToString(),
                        copies = short.Parse(reader["copies"].ToString()),
                        bookID = short.Parse(reader["id"].ToString())
                    });
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConnection.Close();
            }

            return credentials;
        }

        public List<string> Retrieve(string username, string password)
        {

            List<string> credentials = new List<string>();

            try
            {
                sqlConnection = new SqlConnection(connectionString);
                sqlConnection.Open();
                sqlCommand = new SqlCommand("EXEC getSpecificUser @username='" + username + "',@password='" +   password + "';", sqlConnection);
                reader = sqlCommand.ExecuteReader();

                while (reader.Read())
                {
                    credentials.Add(reader["username"].ToString());
                    credentials.Add(reader["store_name"].ToString());
                    credentials.Add(reader["id"].ToString());
                }
      
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConnection.Close();
            }

            return credentials;

        }

        public void Update(int id, int copies)
        {
            try
            {
                sqlConnection = new SqlConnection(connectionString);
                sqlConnection.Open();
                sqlCommand = new SqlCommand("EXEC alterTheExistingBook @id='" + id + "',@copies='" + copies + "';", sqlConnection);
                sqlCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConnection.Close();
            }

        }
    }
}