﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Security.Cryptography;
using System.Text;

namespace Inventory
{
    public class Credentials
    {
        [Required]
        public string username
        {
            get;
            set;
        }

        [Required]
        public string password
        {
            get;
            set;
        }

        public byte[] passwordHash(string password)
        {
            byte[] passwordHash;
            SHA256 encryption = SHA256.Create();
            UTF8Encoding encoding = new UTF8Encoding();
            passwordHash = encryption.ComputeHash(encoding.GetBytes(password));

            return passwordHash;
        }
    }
}