﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Inventory
{
    public class Validator
    {
        public static bool isValidPassword(string password)
        {
            int counter = 0;

            if (password.Length > 7)
            {
                if (char.IsUpper(password[0]))
                {
                    for (int i = 0; i < password.Length; i++)
                    {
                        if (char.IsLetterOrDigit(password[i]))
                            ++counter;
                        else if(password[i] == '@' || password[i] == '$' || password[i] == '_' || password[i] == '(' || password[i] == ')')
                        {
                            ++counter;
                        }
                    }

                    if (counter > 0)
                        return true;
                    else
                        return false;
                }
                else
                    return false;
            }
            else
                return false;
        }

        public static bool isValidName(string name)
        {

            for(int i=0; i<name.Length; i++)
            {
                if (i == name.Length - 1)
                {
                    if (char.IsLetter(name[i]) || name[i] == ' ')
                        return true;
                    else
                        return false;
                }
                else if (char.IsLetter(name[i]) || name[i] == ' ')
                    continue;
                else
                    break;
            }

            return false;
        }

        public static bool isValidEmail(string email)
        {
            if ((email.Contains("@")) && (email.Contains(".com") || email.Contains(".in")))
            {

                for (int i = 0; i < email.Length; i++) 
                {
                    if (i == email.Length - 1)
                    {
                        if (char.IsLetterOrDigit(email[i]) || email[i] == '.' || email[i] == '_' || email[i] == '-' || email[i] == '@')
                            return true;
                        else
                            return false;
                    }
                    else if (char.IsLetterOrDigit(email[i]) || email[i] == '.' || email[i] == '_' || email[i] == '-' || email[i] == '@')
                        continue;
                    else
                        break;
                }

                return false;

            }
            else
                return false;
        }

        public static bool isValidUsername(string email)
        {
            for (int i = 0; i < email.Length; i++)
            {
                if (i == email.Length - 1)
                {
                    if (char.IsLetterOrDigit(email[i]))
                        return true;
                    else
                        return false;
                }
                else if (char.IsLetterOrDigit(email[i]))
                    continue;
                else
                    break;
            }

            return false;
        }

        public static bool isValidSName(string email)
        {
            for (int i = 0; i < email.Length; i++)
            {
                if (i == email.Length - 1)
                {
                    if (char.IsLetterOrDigit(email[i]) || email[i] == ' ')
                        return true;
                    else
                        return false;
                }
                else if (char.IsLetterOrDigit(email[i]) || email[i] == ' ')
                    continue;
                else
                    break;
            }

            return false;
        }

    }

}