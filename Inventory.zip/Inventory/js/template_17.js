let button3 = document.getElementById('close');
let cnf_msg = document.getElementById('cnf_msg');

cnf_msg.style.display = "none";


if (cnf_msg.childElementCount > 1) {
    cnf_msg.style.display = "flex";
    cnf_msg.style.margin = "auto";
    cnf_msg.showModal();
}

button3.addEventListener('click',function(){
    cnf_msg.close();
    cnf_msg.style.display = "none";
});