﻿let button1 = document.getElementById('button1');
let button2 = document.getElementById('button2');


button1.addEventListener('click', function () {
    window.open('Account.aspx');
});

button2.addEventListener('click', function () {
    window.open('Login.aspx');
});