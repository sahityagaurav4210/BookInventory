﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.ModelBinding;

namespace Inventory
{
    public partial class Account : System.Web.UI.Page
    {
        private Repository repository = new Repository();
        private Accounts account = new Accounts();

        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void button1_Click(object sender, EventArgs e)
        {

            try
            {
                if (TryUpdateModel(account, new FormValueProvider(ModelBindingExecutionContext)))
                {
                    if (Validator.isValidPassword(account.Password))
                    {
                        if (Validator.isValidName(account.Name) && Validator.isValidEmail(account.Email) && Validator.isValidUsername(account.Username) && Validator.isValidSName(account.Store_Name)) 
                        {
                            repository.Add(account);
                            cnf_msg.InnerHtml = "";
                            cnf_msg.InnerHtml = "<p class='paras'> Your store has been successfully created!!! </p>";
                            cnf_msg.InnerHtml += "<button class=btn success-btn' type='button' id='close'>Close</button>";
                        }
                        else
                        {
                            cnf_msg.InnerHtml = "";
                            cnf_msg.InnerHtml = "<p class='paras'>Please fill out the form with proper information. </p>";
                            cnf_msg.InnerHtml += "<button class=btn success-btn' type='button' id='close'>Close</button>";
                        }
                    }
                    else
                    {
                        cnf_msg.InnerHtml = "";
                        cnf_msg.InnerHtml = "<p class='paras'>Your password should atleast 8 character long and it must start with a capital letter and it must contains atleast a digit and anyone character out of these characters @,$,(,),_ </p>";
                        cnf_msg.InnerHtml += "<button class=btn success-btn' type='button' id='close'>Close</button>";
                    }
                }

            }
            catch(Exception ex)
            {
                cnf_msg.InnerHtml = "";
                cnf_msg.InnerHtml = "<p class='paras'> Error Message : " + ex.Message + "</p>";
                cnf_msg.InnerHtml += "<button class=btn success-btn' type='button' id='close'>Close</button>";
                
            }
        }

        protected void button2_Click(object sender, EventArgs e)
        {
            
        }
    }
}