﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.ModelBinding;

namespace Inventory
{
    public partial class Admin : System.Web.UI.Page
    {

        private Books book = new Books();
        private Repository repository = new Repository();
        private List<Books> bookDetails;


        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["q"] != null)
            {
                Session.RemoveAll();
                Response.Redirect("Login.aspx");
            }
            else if (Session["username"] != null)
            {
                render();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }

        protected void addBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (TryUpdateModel(book, new FormValueProvider(ModelBindingExecutionContext)))
                {
                    book.user_id = int.Parse(Session["id"].ToString());
                    repository.Add(book);
                    render();
                    Response.Write("<script> alert('Book Inserted !!!'); </script>");
                }
                else
                {
                    render();
                    Response.Write("<script> alert('We're facing some issues right now, please try again !!!'); </script>");
                }
            }
            catch
            {
                Response.Write("Error");
            }
        }

        private void render()
        {
            try
            {
                msg.InnerHtml = "<h1 class='h-primary'>" + Session["sname"] + "</h1>";
                bookDetails = repository.Retrieve();

                if (bookDetails.Count > 1)
                {

                    details.InnerHtml = "<table>";

                    details.InnerHtml += "<tr>";
                    details.InnerHtml += "<th> Book Name </th>";
                    details.InnerHtml += "<th> Author Name </th>";
                    details.InnerHtml += "<th> Price </th>";
                    details.InnerHtml += "<th> Book Edition </th>";
                    details.InnerHtml += "<th> ISBN </th>";
                    details.InnerHtml += "<th> No. of Copies </th>";
                    details.InnerHtml += "<th> Status </th>";
                    details.InnerHtml += "<th> Action </th>";
                    details.InnerHtml += "</tr>";

                    for (int i = 0; i < bookDetails.Count; i++)
                    {
                        if (int.Parse(Session["id"].ToString()) == bookDetails[i].user_id)
                        {
                            details.InnerHtml += "<tr>";
                            details.InnerHtml += "<td>" + bookDetails[i].bookName + "</td>";
                            details.InnerHtml += "<td>" + bookDetails[i].authorName + "</td>";
                            details.InnerHtml += "<td>" + bookDetails[i].bookPrice + "</td>";
                            details.InnerHtml += "<td>" + bookDetails[i].bookEdition + "</td>";
                            details.InnerHtml += "<td>" + bookDetails[i].isbn + "</td>";
                            details.InnerHtml += "<td>" + bookDetails[i].copies + "</td>";

                            if (bookDetails[i].copies > 0)
                            {
                                details.InnerHtml += "<td> In stock </td>";
                                details.InnerHtml += "<td><a href='Update.aspx?id=" + bookDetails[i].bookID + "'        target='_blank'>Update</a></td>";
                            }
                            else
                            {
                                details.InnerHtml += "<td>Out of Stock</td>";
                                details.InnerHtml += "<td><a href='Add.aspx?id=" + bookDetails[i].bookID + "'        target='_blank'>Update</a></td>";
                            }


                            details.InnerHtml += "</tr>";
                        }

                    }

                    details.InnerHtml += "</table>";
                }
                else
                {
                    details.InnerHtml = "<table>";

                    details.InnerHtml += "<tr>";
                    details.InnerHtml += "<th> Book Name </th>";
                    details.InnerHtml += "<th> Author Name </th>";
                    details.InnerHtml += "<th> Price </th>";
                    details.InnerHtml += "<th> Book Edition </th>";
                    details.InnerHtml += "<th> ISBN </th>";
                    details.InnerHtml += "<th> No. of Copies </th>";
                    details.InnerHtml += "<th> Status </th>";
                    details.InnerHtml += "<th> Action </th>";
                    details.InnerHtml += "</tr>";

                    details.InnerHtml += "<tr>";
                    details.InnerHtml += "<td> N/A </td>";
                    details.InnerHtml += "<td> N/A </td>";
                    details.InnerHtml += "<td> N/A </td>";
                    details.InnerHtml += "<td> N/A </td>";
                    details.InnerHtml += "<td> N/A </td>";
                    details.InnerHtml += "<td> N/A </td>";
                    details.InnerHtml += "<td> N/A </td>";
                    details.InnerHtml += "<td> N/A </td>";
                    details.InnerHtml += "</tr>";

                    details.InnerHtml += "</table>";

                }
            }
            catch
            {
                details.InnerHtml = "<table>";

                details.InnerHtml += "<tr>";
                details.InnerHtml += "<th> Book Name </th>";
                details.InnerHtml += "<th> Author Name </th>";
                details.InnerHtml += "<th> Price </th>";
                details.InnerHtml += "<th> Book Edition </th>";
                details.InnerHtml += "<th> ISBN </th>";
                details.InnerHtml += "<th> No. of Copies </th>";
                details.InnerHtml += "<th> Status </th>";
                details.InnerHtml += "<th> Action </th>";
                details.InnerHtml += "</tr>";

                details.InnerHtml += "<tr>";
                details.InnerHtml += "<td> Error </td>";
                details.InnerHtml += "<td> Error </td>";
                details.InnerHtml += "<td> Error </td>";
                details.InnerHtml += "<td> Error </td>";
                details.InnerHtml += "<td> Error </td>";
                details.InnerHtml += "<td> Error </td>";
                details.InnerHtml += "<td> Error </td>";
                details.InnerHtml += "<td> Error </td>";
                details.InnerHtml += "</tr>";

                details.InnerHtml += "</table>";

            }

        }

    }
}