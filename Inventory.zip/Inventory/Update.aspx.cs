﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.ModelBinding;

namespace Inventory
{
    public partial class Update : System.Web.UI.Page
    {
        private soldBooks sBooks = new soldBooks();
        private Repository repository = new Repository();
        private List<string> copies;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                ViewState.Add("id", Request.QueryString["id"]);
        }

        protected void updates_Click(object sender, EventArgs e)
        {
            try
            {

                if (TryUpdateModel(sBooks, new FormValueProvider(ModelBindingExecutionContext)))
                {
                    copies = repository.Retrieve(int.Parse(ViewState["id"].ToString()));
                    repository.Update(int.Parse(ViewState["id"].ToString()), (int.Parse(copies[3]) - sBooks.sold_copies));
                    sBooks.user_id = int.Parse(copies[0]);
                    sBooks.bookName = copies[1];
                    sBooks.authorName = copies[2];
                    repository.Add(sBooks);
                    Response.Write("<script> alert('Book details updated successfully'); </script>");
                }
                else
                {
                    Response.Write("<script> alert('We're facing some issues right now, please try again!!!'); </script>");
                }
            }
            catch(Exception ex)
            {
                Response.Write("<script> alert('Error : " + ex.Message + "'); </script>");
            }

        }
    }
}